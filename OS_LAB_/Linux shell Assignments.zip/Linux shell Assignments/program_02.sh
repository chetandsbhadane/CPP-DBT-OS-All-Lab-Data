#!/bin/bash

read fName
read mName
read lName

echo "Hello $fName $mName $lName"
